<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php
	if(isset($_POST[text1])&&$_POST[text1]=="zhimakaimen"){
		echo "flag is:";
    }else{
    	echo "尚未登录或口令错误";
    }
?>
<form action="./index.php" method="post">
	<p>输入框：<input type="password" value="" name="text1" maxlength="10"><br>
	请输入口令：zhimakaimen
	<input type="submit" value="开门">
</form>

</html>
