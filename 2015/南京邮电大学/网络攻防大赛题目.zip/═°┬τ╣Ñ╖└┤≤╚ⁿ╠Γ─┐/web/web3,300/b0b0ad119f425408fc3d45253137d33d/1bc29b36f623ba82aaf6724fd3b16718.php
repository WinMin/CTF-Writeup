<?php
header("tip:1.bash_history");
?>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <h1>哈哈哈哈哈哈你上当啦，这里什么都没有，TIP在我脑袋<!-- head-->里</h1>