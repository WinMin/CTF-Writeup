<?php
header("power-by:i am a linux~~~");
if(isset($_COOKIE[user])){
	if(base64_decode($_COOKIE[user])=="root"){
		echo "flag is:";
	}
}else{
	setcookie("user",base64_encode("guest"));
}
?>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head><title>xx网站后台管理系统</title>
</head>
<?php
	if(@base64_decode($_COOKIE[user])!="root"){
		echo "你没有后台的访问权限";
	}
?>

</html>
