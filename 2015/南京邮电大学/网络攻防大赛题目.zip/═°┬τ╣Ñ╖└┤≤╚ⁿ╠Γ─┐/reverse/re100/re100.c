#include<stdio.h>
int main(){
char flag[]="flag:nctf{most_easy_reverse}";
char pass1[]="haoxiangzhaoyigenvpengyou";
char pass2[1024];
printf("please input password!\n");
scanf("%s",pass2);
if(!strcmp(pass1,pass2)){
	printf("%s\n",flag);
}else{
	printf("password error!");
}
system("pause");
return 0;
}