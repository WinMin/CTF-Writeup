import base64
import md5
def md5en(src):
	m1 = md5.new()   
	m1.update(src)   
	return m1.hexdigest()  
a=0
string='YMFZZTY0D3RMD3RMMTIZ'
for i in range(0,len(string)):
	if string[i]!='=':
		a+=1
b=a*'1'
c=int(b,2)
print b
for i in range(1,c+1):
	mm=str(bin(i))
	mm=mm[2:]
	nn=''
	for j in range(0,len(mm)):
		if mm[j]=='0':
			nn+=string[j].lower()
		else:
			nn+=string[j]
	try:
		msg=base64.b64decode(nn)
		if md5en(msg)=='16478a151bdd41335dcd69b270f6b985':
			print msg
	except:
		pass
