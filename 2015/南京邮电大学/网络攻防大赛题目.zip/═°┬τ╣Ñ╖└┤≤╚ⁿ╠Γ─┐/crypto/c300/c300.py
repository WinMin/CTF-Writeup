import base64
def change(ch):
	if ord(ch)<92:
		return chr(ord(ch)+32)
	else:
		return chr(ord(ch)-32)
if __name__ == '__main__':
	flag='??????????????'
	rawstr=base64.b64encode(flag)
	finalstr=''
	for i in range(0,len(rawstr)):
		if ord(rawstr[i])>96 and ord(rawstr[i])<123:
			finalstr+=change(rawstr[i])
		else:
			finalstr+=rawstr[i]
	print rawstr
	print finalstr