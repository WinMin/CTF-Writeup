mm=raw_input()
re=''
for i in range(0,len(mm)):
	x=ord(mm[i])-97
	mmm=str(bin(x))
	mmm=mmm[2:]
	mmm='0'*(5-len(mmm))+mmm
	s=''
	for j in range(0,len(mmm)):
		if mmm[j]=='1':
			s+='b'
		else:
			s+='a'
	re+=s+' '
print re