print 'please input your password!'
f1='nctf{'
f5='complied_'
flag='i"m not flag'
f2='python_'
f3='biubiubiu'
f4='}'
password=raw_input()
truepass=f1+f5+f2+f3+f4
password=password.replace('\\n','')
if password==truepass:
	print flag
else:
	print 'pass error!'