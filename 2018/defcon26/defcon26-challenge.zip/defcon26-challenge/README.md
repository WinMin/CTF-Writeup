# DEF CON 26th

## reverse

Description: KoH game of assembly/disassembly.
Type: `KING_OF_THE_HILL`

## doublethink

Description: How many conflicting ideas can you hold in one thought?
Type: `KING_OF_THE_HILL`

## pointless

Description: pointless.Flag location /flag.You may patch up to 200 bytes in the pointless binary.
Type: `A&D`

## bew

Description: Finally the Thought-CyberCrimes Reporting System is up and running. Report your suspects now, because in the new era even thinking about a cybercrime is punishable. 
Type: `A&D`

## twoplustwo

Description: A very shy calculator. Flag location is /flag, and you may patch up to 24 bytes in the twoplustwo binary.
Type: `A&D`

## OOOediter

Description: The vim vs emacs religious war finally comes to an end. The Order has mandated the use of OOO Editor. 
Type: `A&D`

## poool

Description: pay per share stratum mining pool~. 
Type: `A&D`

## vchat

Description: The Order of the Overflow has assigned you a personal virtual assistant. Obey the assistant. You may patch up to 100 bytes in the vbot binary.
Type: `A&D`

## reeducation

Description: You have arrived at the OOO re-education center. You may patch up to 16 bytes in the reeducation binary
Type: `A&D`

## propaganda

Description: KoH on binary patching
Type: `KING_OF_THE_HILL`





